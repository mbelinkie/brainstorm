const BANK_URL = "./music-trivia.question-bank.json";
let bank;
let selection = { roundIndex: 0, questionIndex: 0 };
let originalBank;

const $ = (selector) => document.querySelector(selector);
const clone = (value) => structuredClone(value);
const escapeHtml = (value = "") => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", "\"": "&quot;" }[char]));
const question = () => bank?.rounds?.[selection.roundIndex]?.questions?.[selection.questionIndex];
const selectedRound = () => bank?.rounds?.[selection.roundIndex];
const letters = (index) => String.fromCharCode(65 + index);
const typeLabel = (type) => type.replaceAll("_", " ");

function markChanged() {
  $("#save-state").textContent = "Edited locally — download when ready";
  $("#raw-json").value = JSON.stringify(bank, null, 2);
}

function renderNav() {
  $("#nav-title").textContent = bank.title || "Untitled question bank";
  $("#round-nav").innerHTML = bank.rounds.map((round, roundIndex) => `
    <section class="round-group"><span class="round-label">${escapeHtml(round.title)}</span>
      ${round.questions.map((item, questionIndex) => `<button class="nav-question ${selection.roundIndex === roundIndex && selection.questionIndex === questionIndex ? "is-active" : ""}" data-select="${roundIndex}:${questionIndex}"><small>${escapeHtml(typeLabel(item.type))}</small>${escapeHtml(item.prompt || "Untitled question")}</button>`).join("")}
    </section>`).join("");
  document.querySelectorAll("[data-select]").forEach((button) => button.addEventListener("click", () => {
    const [roundIndex, questionIndex] = button.dataset.select.split(":").map(Number);
    selection = { roundIndex, questionIndex }; render();
  }));
}

function field(label, key, value, { textarea = false, type = "text" } = {}) {
  const control = textarea
    ? `<textarea data-field="${key}" aria-label="${escapeHtml(label)}">${escapeHtml(value)}</textarea>`
    : `<input type="${type}" data-field="${key}" aria-label="${escapeHtml(label)}" value="${escapeHtml(value)}" />`;
  return `<div class="field"><label>${label}</label>${control}</div>`;
}

function optionsEditor(item) {
  if (!item.options) return "";
  const isChoice = ["single_choice", "multiple_choice", "true_false", "image_selection"].includes(item.type);
  const isMatching = item.type === "matching";
  const rows = item.options.map((option, index) => {
    const checked = item.correctOptionIds?.includes(option.id) ? "checked" : "";
    return `<div class="option-row"><span class="choice-key">${letters(index)}</span><input data-option-label="${index}" value="${escapeHtml(option.label)}" aria-label="Option ${letters(index)}" />${isChoice ? `<label class="correct-check"><input type="${item.type === "multiple_choice" ? "checkbox" : "radio"}" name="correct-option" data-correct-option="${index}" ${checked} /> Correct</label>` : ""}${isMatching ? "" : `<button class="icon-button" data-remove-option="${index}" title="Remove option">×</button>`}</div>`;
  }).join("");
  return `<section class="section"><div class="section-head"><span class="section-label">${isMatching ? "Song-title options" : "Answer options"}</span>${!isMatching ? '<button class="button button-quiet" data-add-option>+ Option</button>' : ""}</div>${rows}</section>`;
}

function answerEditor(item) {
  if (item.type === "fill_in_the_blank") {
    const blanks = item.blanks || [];
    return `<section class="section"><span class="section-label">Accepted answers (comma-separated)</span>${blanks.map((blank, index) => `<div class="field"><input data-blank="${index}" value="${escapeHtml((blank.acceptedAnswers || []).join(", "))}" /></div>`).join("")}</section>`;
  }
  if (item.type === "short_answer") return `<section class="section"><span class="section-label">Accepted answers (comma-separated)</span><div class="field"><input data-accepted value="${escapeHtml((item.acceptedAnswers || []).join(", "))}" /></div></section>`;
  if (item.type === "arrange_in_order") {
    const items = item.items || [];
    return `<section class="section"><span class="section-label">Order items and correct positions</span>${items.map((entry, index) => `<div class="order-row"><span class="choice-key">${index + 1}</span><input data-order-label="${index}" value="${escapeHtml(entry.label)}" /><select data-order-correct="${index}">${items.map((_, position) => `<option value="${position}" ${item.correctOrder?.[position] === entry.id ? "selected" : ""}>Position ${position + 1}</option>`).join("")}</select></div>`).join("")}</section>`;
  }
  if (item.type === "matching") {
    return `<section class="section"><span class="section-label">Clip-to-title answer key</span>${(item.clips || []).map((clip, index) => `<div class="pair-row"><span class="choice-key">Clip ${index + 1}</span><input data-clip-label="${index}" value="${escapeHtml(clip.label)}" aria-label="Clip label" /><select data-pair="${index}">${item.options.map((option) => `<option value="${option.id}" ${item.correctPairs?.[clip.id] === option.id ? "selected" : ""}>${escapeHtml(option.label)}</option>`).join("")}</select></div>`).join("")}</section>`;
  }
  return "";
}

function audioEditor(item) {
  if (!item.audio) return "";
  return `<section class="section"><div class="section-head"><span class="section-label">Host-only audio cue</span></div><div class="field-grid">${field("Opaque asset ID", "audio.assetId", item.audio.assetId)}${field("Suggested window", "audio.suggestedWindow", item.audio.suggestedWindow)}</div>${field("Production cue", "audio.cue", item.audio.cue, { textarea: true })}</section>`;
}

function renderEditor() {
  const item = question();
  const round = selectedRound();
  if (!item) { $("#form-editor").innerHTML = $("#empty-state").innerHTML; return; }
  $("#question-location").textContent = `${round.title} · Question ${selection.questionIndex + 1}`;
  $("#editor-title").textContent = item.id || "Question editor";
  $("#form-editor").innerHTML = `
    <div class="field-grid">${field("Question ID", "id", item.id)}<div class="field"><label>Question type</label><select data-field="type" aria-label="Question type">${["single_choice","multiple_choice","true_false","image_selection","arrange_in_order","fill_in_the_blank","short_answer","matching"].map((type) => `<option value="${type}" ${item.type === type ? "selected" : ""}>${escapeHtml(typeLabel(type))}</option>`).join("")}</select></div></div>
    ${field("Player prompt", "prompt", item.prompt, { textarea: true })}
    <div class="field-grid">${field(item.type === "matching" ? "Points per pair" : "Points", item.type === "matching" ? "pointsPerPair" : "points", item.type === "matching" ? item.pointsPerPair : item.points, { type: "number" })}${field("Host reveal", "hostReveal", item.hostReveal || "", { textarea: true })}</div>
    ${audioEditor(item)}${optionsEditor(item)}${answerEditor(item)}
  `;
  bindEditorEvents();
}

function renderPreview() {
  const item = question();
  if (!item) { $("#preview").innerHTML = ""; return; }
  const correct = new Set(item.correctOptionIds || []);
  let body = "";
  if (item.options) body = `<div class="preview-options">${item.options.map((option, index) => `<div class="preview-option ${correct.has(option.id) ? "correct" : ""}"><span class="choice-key">${letters(index)}</span>${escapeHtml(option.label)}</div>`).join("")}</div>`;
  if (item.type === "matching") body = `<div class="preview-answer">10-pair finale · ${item.pointsPerPair || 1} point per correct match</div>`;
  if (["fill_in_the_blank", "short_answer"].includes(item.type)) body = `<div class="preview-answer">Free-text response · accepted answer variants are graded automatically.</div>`;
  if (item.type === "arrange_in_order") body = `<div class="preview-options">${(item.items || []).map((entry, index) => `<div class="preview-option"><span class="choice-key">${index + 1}</span>${escapeHtml(entry.label)}</div>`).join("")}</div>`;
  $("#preview").innerHTML = `<span class="preview-type">${escapeHtml(typeLabel(item.type))}</span><h2>${escapeHtml(item.prompt)}</h2>${item.audio ? `<div class="preview-answer"><strong>Host audio:</strong> ${escapeHtml(item.audio.suggestedWindow || "Clip")}</div>` : ""}${body}<div class="preview-answer"><strong>Reveal:</strong> ${escapeHtml(item.hostReveal || "Add a host reveal note.")}</div>`;
}

function render() { renderNav(); renderEditor(); renderPreview(); $("#raw-json").value = JSON.stringify(bank, null, 2); }

function updateField(key, value) {
  const item = question();
  if (key.startsWith("audio.")) { item.audio ||= {}; item.audio[key.slice(6)] = value; } else item[key] = key === "points" || key === "pointsPerPair" ? Number(value) : value;
  markChanged(); renderNav(); renderPreview();
}

function bindEditorEvents() {
  document.querySelectorAll("[data-field]").forEach((input) => {
    const commit = () => { updateField(input.dataset.field, input.value); renderEditor(); };
    if (input.tagName === "SELECT" || input.type === "number") input.addEventListener("change", commit);
    else input.addEventListener("input", () => {
      const key = input.dataset.field;
      const item = question();
      if (key.startsWith("audio.")) { item.audio ||= {}; item.audio[key.slice(6)] = input.value; } else item[key] = input.value;
      markChanged(); renderNav(); renderPreview();
    });
  });
  document.querySelectorAll("[data-option-label]").forEach((input) => input.addEventListener("input", () => { question().options[Number(input.dataset.optionLabel)].label = input.value; markChanged(); renderNav(); renderPreview(); }));
  document.querySelectorAll("[data-correct-option]").forEach((input) => input.addEventListener("change", () => { const option = question().options[Number(input.dataset.correctOption)]; if (question().type === "multiple_choice") { const set = new Set(question().correctOptionIds || []); input.checked ? set.add(option.id) : set.delete(option.id); question().correctOptionIds = [...set]; } else question().correctOptionIds = [option.id]; markChanged(); renderEditor(); renderPreview(); }));
  document.querySelectorAll("[data-remove-option]").forEach((button) => button.addEventListener("click", () => { const index = Number(button.dataset.removeOption); const [removed] = question().options.splice(index, 1); question().correctOptionIds = (question().correctOptionIds || []).filter((id) => id !== removed.id); markChanged(); render(); }));
  $("[data-add-option]")?.addEventListener("click", () => { const item = question(); item.options.push({ id: crypto.randomUUID(), label: "New option" }); markChanged(); render(); });
  document.querySelectorAll("[data-blank]").forEach((input) => input.addEventListener("input", () => { question().blanks[Number(input.dataset.blank)].acceptedAnswers = input.value.split(",").map((entry) => entry.trim()).filter(Boolean); markChanged(); renderPreview(); }));
  $("[data-accepted]")?.addEventListener("input", (event) => { question().acceptedAnswers = event.target.value.split(",").map((entry) => entry.trim()).filter(Boolean); markChanged(); renderPreview(); });
  document.querySelectorAll("[data-order-label]").forEach((input) => input.addEventListener("input", () => { question().items[Number(input.dataset.orderLabel)].label = input.value; markChanged(); renderPreview(); }));
  document.querySelectorAll("[data-order-correct]").forEach((select) => select.addEventListener("change", () => { const item = question(); const selectedItem = item.items[Number(select.dataset.orderCorrect)]; item.correctOrder[Number(select.value)] = selectedItem.id; markChanged(); }));
  document.querySelectorAll("[data-clip-label]").forEach((input) => input.addEventListener("input", () => { question().clips[Number(input.dataset.clipLabel)].label = input.value; markChanged(); renderPreview(); }));
  document.querySelectorAll("[data-pair]").forEach((select) => select.addEventListener("change", () => { const clip = question().clips[Number(select.dataset.pair)]; question().correctPairs[clip.id] = select.value; markChanged(); renderPreview(); }));
}

function addQuestion() {
  const round = selectedRound();
  round.questions.push({ id: `question-${crypto.randomUUID().slice(0, 8)}`, type: "single_choice", prompt: "New question", options: [{ id: "a", label: "Option A" }, { id: "b", label: "Option B" }], correctOptionIds: ["a"], points: 1, hostReveal: "Add the answer reveal note." });
  selection.questionIndex = round.questions.length - 1; markChanged(); render();
}

function download() {
  const blob = new Blob([JSON.stringify(bank, null, 2) + "\n"], { type: "application/json" });
  const link = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `${(bank.id || "music-trivia-question-bank").replace(/[^a-z0-9-]/gi, "-")}.json` });
  link.click(); URL.revokeObjectURL(link.href); $("#save-state").textContent = "Downloaded — your working copy is still open";
}

$("#download").addEventListener("click", download);
$("#add-question").addEventListener("click", addQuestion);
$("#delete-question").addEventListener("click", () => { const round = selectedRound(); if (round.questions.length <= 1 || !confirm("Delete this question? This cannot be undone in the editor.")) return; round.questions.splice(selection.questionIndex, 1); selection.questionIndex = Math.max(0, selection.questionIndex - 1); markChanged(); render(); });
$("#apply-raw").addEventListener("click", () => { try { const candidate = JSON.parse($("#raw-json").value); if (!Array.isArray(candidate.rounds)) throw new Error("Expected a top-level rounds array."); bank = candidate; selection = { roundIndex: 0, questionIndex: 0 }; $("#raw-status").textContent = "Applied."; markChanged(); render(); } catch (error) { $("#raw-status").textContent = `Not applied: ${error.message}`; } });
$("#import-file").addEventListener("change", async (event) => { const file = event.target.files?.[0]; if (!file) return; try { const candidate = JSON.parse(await file.text()); if (!Array.isArray(candidate.rounds)) throw new Error("Expected a top-level rounds array."); bank = candidate; selection = { roundIndex: 0, questionIndex: 0 }; $("#save-state").textContent = `Imported ${file.name} — download to keep edits`; render(); } catch (error) { alert(`Could not import this JSON: ${error.message}`); } finally { event.target.value = ""; } });

try { bank = await fetch(BANK_URL, { cache: "no-store" }).then((response) => { if (!response.ok) throw new Error("Question bank not found"); return response.json(); }); originalBank = clone(bank); $("#save-state").textContent = "Loaded — edits stay in this browser until downloaded"; render(); } catch (error) { $("#nav-title").textContent = "Could not load question bank"; $("#save-state").textContent = error.message; }
