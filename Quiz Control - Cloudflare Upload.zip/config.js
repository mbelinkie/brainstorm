// Safe to publish: Supabase publishable keys identify the public browser API;
// row-level security and protected RPCs enforce access. Never add a secret key.
window.QUIZ_PLATFORM_CONFIG = {
  supabaseUrl: "https://jwrtxdmawjmkuvxgpmlq.supabase.co",
  supabasePublishableKey: "sb_publishable_QEIjNfLqSc_bMO0MNjMUXQ_Uc468owl",
  defaultQuizVersionId: "b7995faa-2fc6-448a-a9ab-43d97cdc1941"
};
