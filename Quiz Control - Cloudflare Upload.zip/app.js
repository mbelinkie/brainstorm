import { randomRoomSecret, roomApi } from "./room-api.js";

const params = new URLSearchParams(location.search);
const view = params.get("view") || "landing";
const roomCode = params.get("room") || "8J4K2P";
const localChannel = new BroadcastChannel(`quiz-control:${roomCode}`);
const config = window.QUIZ_PLATFORM_CONFIG || {};
let realtimeChannel = null;
let hostQuizDefinition = null;

let hostQuestion = {
  id: "sample-question",
  round: 1,
  roundTitle: "Name That Tune",
  prompt: "Which song opens with this unmistakable piano line?",
  options: ["A Thousand Miles", "Clocks", "Someone Like You", "Piano Man"],
  correctOption: 0,
  audioLabel: "Audio clip • 00:12",
  audioHelp: "Audio plays in the host tab being shared to the call."
};

const defaultState = {
  phase: "lobby",
  question: toPlayerQuestion(hostQuestion),
  submitted: {},
  players: []
};

function toPlayerQuestion(question) {
  const { correctOption, correctOptionIds, acceptedAnswers, correctPairs, correctOrder, ...playerQuestion } = question;
  return playerQuestion;
}

function correctOptionId(question) {
  return question.correctOptionIds?.[0] || question.options?.[question.correctOption]?.id || null;
}

function publicRoomState() {
  const roundIndex = Math.max(0, (state.question?.round || 1) - 1);
  const questionIndex = Math.max(0, (state.question?.questionInRound || 1) - 1);
  const round = hostQuizDefinition?.rounds?.[roundIndex];
  const playerQuestion = {
    ...toPlayerQuestion(hostQuestion),
    round: roundIndex + 1,
    roundTitle: round?.title || state.question?.roundTitle || "Round 1",
    questionInRound: questionIndex + 1,
    questionsInRound: round?.questions?.length || state.question?.questionsInRound || 1
  };
  return {
    phase: state.phase,
    revision: state.revision || 0,
    questionId: hostQuestion.id,
    question: playerQuestion,
    revealedCorrectOptionId: state.phase === "reveal" ? correctOptionId(hostQuestion) : null,
    submitted: {},
    players: state.players
  };
}

function setHostQuestion(roundIndex, questionIndex) {
  const round = hostQuizDefinition?.rounds?.[roundIndex];
  const nextQuestion = round?.questions?.[questionIndex];
  if (!nextQuestion) return false;
  hostQuestion = nextQuestion;
  state = {
    ...state,
    phase: "lobby",
    questionId: nextQuestion.id,
    question: {
      ...toPlayerQuestion(nextQuestion),
      round: roundIndex + 1,
      roundTitle: round.title,
      questionInRound: questionIndex + 1,
      questionsInRound: round.questions.length
    },
    submitted: {}
  };
  return true;
}

async function advanceQuestion() {
  const roundIndex = (state.question.round || 1) - 1;
  const questionIndex = (state.question.questionInRound || 1) - 1;
  const nextInRound = questionIndex + 1;
  const nextRound = nextInRound >= (state.question.questionsInRound || 1) ? roundIndex + 1 : roundIndex;
  const nextIndex = nextRound === roundIndex ? nextInRound : 0;
  if (!setHostQuestion(nextRound, nextIndex)) return;
  await persistHostState();
  emit();
  render();
}

let state = structuredClone(defaultState);
let playerId = sessionStorage.getItem("musicTriviaPlayerId") || crypto.randomUUID();
sessionStorage.setItem("musicTriviaPlayerId", playerId);
let playerName = sessionStorage.getItem("musicTriviaPlayerName") || "";
let selected = null;

const app = document.querySelector("#app");

function acceptSubmission(payload) {
  if (view !== "host" || state.phase !== "open" || !payload?.playerId) return;
  state.submitted[payload.playerId] = payload.answer;
  if (!state.players.find((player) => player.id === payload.playerId)) state.players.push({ id: payload.playerId, name: payload.playerName || "Guest", points: 0 });
  emit();
}

function receive(message) {
  const data = message?.data || message;
  if (data?.type === "state") {
    state = data.state;
    render();
  }
  if (data?.type === "submission") acceptSubmission(data.payload);
}
localChannel.onmessage = receive;

function emit() {
  if (view !== "host") return;
  const outboundState = params.has("room") ? publicRoomState() : state;
  localChannel.postMessage({ type: "state", state: outboundState });
  realtimeChannel?.send({ type: "broadcast", event: "state", payload: { state: outboundState } });
}

async function persistHostState() {
  const hostSecret = sessionStorage.getItem(`quiz-host-secret:${roomCode}`);
  if (!hostSecret || !params.has("room")) return;
  try {
    const phaseMap = { lobby: "lobby", open: "question_open", locked: "question_locked", reveal: "answer_reveal" };
    const result = await roomApi.setRoomState({
      roomCode,
      hostSecret,
      phase: phaseMap[state.phase] || "lobby",
      roundIndex: Math.max(0, (state.question?.round || 1) - 1),
      questionIndex: Math.max(0, (state.question?.questionInRound || 1) - 1),
      publicState: publicRoomState()
    });
    state.revision = result.revision;
  } catch (error) {
    console.warn("Could not save host room state.", error);
  }
}

function sendSubmission(answer) {
  const payload = { playerId, playerName, answer };
  localChannel.postMessage({ type: "submission", payload });
  realtimeChannel?.send({ type: "broadcast", event: "submission", payload });
}

async function connectHostedRoom() {
  if (!config.supabaseUrl || !config.supabasePublishableKey) return;
  try {
    const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2");
    const supabase = createClient(config.supabaseUrl, config.supabasePublishableKey);
    realtimeChannel = supabase.channel(`quiz-room:${roomCode}`, { config: { broadcast: { self: false } } });
    realtimeChannel.on("broadcast", { event: "state" }, ({ payload }) => {
      receive({ type: "state", state: payload?.state });
    });
    realtimeChannel.on("broadcast", { event: "submission" }, ({ payload }) => receive({ type: "submission", payload }));
    realtimeChannel.on("broadcast", { event: "request-state" }, () => {
      if (view === "host") emit();
    });
    realtimeChannel.subscribe((status) => {
      if (status !== "SUBSCRIBED") return;
      if (view === "host") emit();
      else realtimeChannel.send({ type: "broadcast", event: "request-state", payload: {} });
    });
    if (view === "host" && params.has("room")) {
      const hostSecret = sessionStorage.getItem(`quiz-host-secret:${roomCode}`);
      if (hostSecret) {
        const definition = await roomApi.getHostQuizDefinition({ roomCode, hostSecret });
        hostQuizDefinition = definition;
        const savedRoom = await roomApi.getHostRoomState({ roomCode, hostSecret });
        const hasSavedQuestion = savedRoom.state?.questionId;
        if (hasSavedQuestion && setHostQuestion(savedRoom.roundIndex, savedRoom.questionIndex)) {
          state = { ...state, ...savedRoom.state, revision: savedRoom.revision, phase: ({ lobby: "lobby", question_open: "open", question_locked: "locked", answer_reveal: "reveal" })[savedRoom.phase] || "lobby" };
        } else if (setHostQuestion(0, 0)) {
          await persistHostState();
        }
        emit();
        render();
      }
    }
    if (view === "player" && params.has("room") && playerName) {
      const joined = await roomApi.joinRoom({ roomCode, displayName: playerName, playerToken: playerId });
      state = { ...state, ...joined.state, revision: joined.revision };
      render();
    }
  } catch (error) {
    console.warn("Hosted room unavailable; continuing with local demo transport.", error);
  }
}

async function setPhase(phase) {
  state.phase = phase;
  await persistHostState();
  emit();
  render();
}
async function lockQuestion() {
  const hostSecret = sessionStorage.getItem(`quiz-host-secret:${roomCode}`);
  if (!params.has("room") || !hostSecret) {
    setPhase("locked");
    return;
  }
  try {
    const result = await roomApi.lockAndScore({ roomCode, hostSecret });
    state.phase = "locked";
    state.revision = result.revision;
    state.players = await roomApi.getLeaderboard({ roomCode, accessToken: hostSecret });
    await persistHostState();
    emit();
    render();
  } catch (error) {
    alert(`Could not lock and score this question: ${error.message}`);
  }
}
function reset() { state = structuredClone(defaultState); selected = null; emit(); render(); }

function shell(content, isPlayer = false) {
  return `<section class="${isPlayer ? "player-shell" : "shell"}">${content}</section>`;
}

function brandTopbar(host = false) {
  return `<header class="topbar"><div class="brand"><span class="brand-mark">K</span><span>QUIZ CONTROL</span></div>${host ? '<span class="host-badge">HOST VIEW</span>' : `<span class="room-badge">ROOM ${roomCode}</span>`}</header>`;
}

function renderLanding() {
  app.innerHTML = shell(`${brandTopbar()}<section class="landing"><div class="landing-card"><div class="landing-copy"><p class="eyebrow">Kaplan presents</p><h1>Run a great quiz, any subject.</h1><p>A host-led game platform with synchronized phones, optional live audio, and a shared scoreboard.</p><div class="landing-actions">${roomApi.configured ? '<button class="btn btn-primary" data-create-room>Create hosted room</button>' : '<a class="btn btn-primary" href="?view=host">Open host demo</a>'}<a class="btn btn-secondary" href="?view=player">Open player demo</a><a class="btn btn-secondary" href="./author.html">Edit question bank</a></div></div><div class="landing-visual"><div class="vinyl"></div></div></div></section>`);
}

function answerButtons({player = false} = {}) {
  const question = player ? state.question : hostQuestion;
  if (!question.options) return "";
  return question.options.map((option, index) => {
    const multiple = question.type === "multiple_choice";
    const current = player && (multiple ? Array.isArray(selected) && selected.includes(option.id) : selected === option.id);
    const revealed = state.phase === "reveal";
    const correct = revealed && (player ? option.id === state.revealedCorrectOptionId : option.id === correctOptionId(hostQuestion));
    const wrong = revealed && player && current && !correct;
    return `<button class="answer ${current ? "is-selected" : ""} ${correct ? "is-correct" : ""} ${wrong ? "is-wrong" : ""}" data-answer="${option.id}" ${state.phase !== "open" && player ? "disabled" : ""}><span class="key">${String.fromCharCode(65 + index)}</span><span>${option.label}</span></button>`;
  }).join("");
}

function answerControl({ player = false } = {}) {
  const question = player ? state.question : hostQuestion;
  if (["single_choice", "multiple_choice", "true_false", "image_selection"].includes(question.type)) return `<div class="answer-grid">${answerButtons({ player })}</div>`;
  if (["short_answer", "fill_in_the_blank", "numeric_estimate"].includes(question.type)) return `<div class="player-answers"><label class="field"><span>${question.type === "numeric_estimate" ? "Your estimate" : "Your answer"}</span><input data-text-answer ${player && state.phase === "open" ? "" : "disabled"} value="${typeof selected === "string" ? selected : ""}" placeholder="Type your answer" /></label></div>`;
  if (question.type === "arrange_in_order") return `<div class="player-answers order-answer">${(question.items || []).map((item, index) => `<label class="field"><span>${item.label}</span><select data-order-answer="${item.id}" ${player && state.phase === "open" ? "" : "disabled"}><option value="">Choose position</option>${(question.items || []).map((_, position) => `<option value="${position + 1}" ${selected?.[item.id] === String(position + 1) ? "selected" : ""}>${position + 1}</option>`).join("")}</select></label>`).join("")}</div>`;
  if (question.type === "matching") return `<div class="player-answers matching-answer">${(question.clips || []).map((clip) => { const usedElsewhere = new Set(Object.entries(selected || {}).filter(([clipId]) => clipId !== clip.id).map(([, optionId]) => optionId)); return `<label class="field"><span>${clip.label}</span><select data-match-answer="${clip.id}" ${player && state.phase === "open" ? "" : "disabled"}><option value="">Choose a song</option>${(question.options || []).map((option) => `<option value="${option.id}" ${selected?.[clip.id] === option.id ? "selected" : ""} ${usedElsewhere.has(option.id) ? "disabled" : ""}>${option.label}</option>`).join("")}</select></label>`; }).join("")}</div>`;
  return "<p>This question type is ready for the host but has no player control yet.</p>";
}

function answerReady(question = state.question) {
  if (["multiple_choice"].includes(question.type)) return Array.isArray(selected) && selected.length > 0;
  if (["short_answer", "fill_in_the_blank", "numeric_estimate"].includes(question.type)) return typeof selected === "string" && selected.trim().length > 0;
  if (question.type === "arrange_in_order") return (question.items || []).every((item) => selected?.[item.id]);
  if (question.type === "matching") return (question.clips || []).every((clip) => selected?.[clip.id]);
  return typeof selected === "string";
}

function audioPanel() {
  const audio = hostQuestion.audio || (hostQuestion.audioLabel ? { suggestedWindow: hostQuestion.audioLabel, cue: hostQuestion.audioHelp } : null);
  if (!audio) return "";
  return `<div class="audio-panel"><button class="audio-play" data-play title="Play demo audio">▶</button><div class="audio-copy"><strong>${audio.suggestedWindow || hostQuestion.audioLabel || "Audio clip"}</strong><span>${audio.cue || hostQuestion.audioHelp || "Audio plays in the host tab being shared to the call."}</span></div><div class="audio-wave" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></div></div>`;
}

function leaderboard() {
  return `<section class="leaderboard-card"><h3>Current leaderboard</h3><div class="leaderboard">${state.players.sort((a,b) => b.points-a.points).map((p, i) => `<div class="leader"><span class="place">${i + 1}</span><span><b>${p.name}</b><br/><small>${i === 0 ? "Holding the lead" : "In the mix"}</small></span><b>${p.points}</b></div>`).join("")}</div></section>`;
}

function renderHost() {
  const submittedCount = Object.keys(state.submitted).length;
  const playerUrl = `${location.origin}${location.pathname}?view=player&room=${encodeURIComponent(roomCode)}`;
  app.innerHTML = shell(`${brandTopbar(true)}<main class="host-layout"><div class="game-meta"><span><strong>${hostQuizDefinition?.title || "Quiz night"}</strong> · Room ${roomCode}</span><span class="progress" aria-label="Round progress"><i class="active"></i><i></i><i></i><i></i><i></i></span></div><section class="round-panel"><span class="round-number">Round ${state.question.round || 1} of ${hostQuizDefinition?.rounds?.length || 5}</span><h1>${state.question.roundTitle}</h1><p>${state.phase === "lobby" ? "Players are joining. Start when you are ready." : state.phase === "reveal" ? "Answer revealed. Celebrate the recognition, then move on." : "Listen closely—your players are answering on their phones."}</p></section><div class="game-grid"><section class="question-card"><p class="eyebrow">${state.phase === "lobby" ? "Lobby" : state.phase === "reveal" ? "Answer reveal" : `Question ${state.question.questionInRound || 1} of ${state.question.questionsInRound || 5}`}</p><h2>${state.question.prompt}</h2>${audioPanel()}${answerControl()}</section><aside class="host-panel"><h3>Session control</h3><div class="stat"><strong>${submittedCount}<span> / ${state.players.length}</span></strong><span>answers received</span></div>${state.phase === "lobby" ? `<div class="field"><label>Player join link</label><input readonly value="${playerUrl}" aria-label="Player join link" /><button class="btn btn-secondary" data-copy-link>Copy link</button></div>` : ""}<div class="host-actions">${state.phase === "lobby" ? '<button class="btn btn-primary" data-phase="open">Start question <span class="keyhint">N</span></button>' : state.phase === "open" ? '<button class="btn btn-primary" data-phase="locked">Lock answers <span class="keyhint">L</span></button>' : state.phase === "locked" ? '<button class="btn btn-primary" data-phase="reveal">Reveal answer <span class="keyhint">R</span></button>' : hostQuizDefinition ? '<button class="btn btn-primary" data-next>Next question <span class="keyhint">N</span></button>' : '<button class="btn btn-primary" data-reset>Reset demo <span class="keyhint">↺</span></button>'}<button class="btn btn-secondary" data-player>Add demo player</button></div>${leaderboard()}</aside></div></main>`);
}

function renderPlayer() {
  if (params.has("room") && !playerName) {
    app.innerHTML = shell(`<main class="player-main">${brandTopbar()}<section class="player-card"><header class="player-round"><p class="eyebrow" style="color:#ffc82e">Join room ${roomCode}</p><h1>Ready to play?</h1></header><section class="player-question"><p>Enter the name you want shown on the leaderboard.</p><label class="field"><span>Display name</span><input data-player-name maxlength="32" autocomplete="nickname" placeholder="Your name" /></label><div class="submit-bar"><button class="btn btn-primary" data-join-room>Join quiz</button></div></section></section></main>`, true);
    return;
  }
  const isSubmitted = Boolean(state.submitted[playerId]);
  const phaseMessage = state.phase === "lobby" ? "The host will start shortly." : state.phase === "locked" ? "Answers are locked." : state.phase === "reveal" ? "Answer revealed." : isSubmitted ? "Answer submitted. You can still change it until the host locks the question." : "Choose your answer, then submit.";
  app.innerHTML = shell(`<main class="player-main">${brandTopbar()}<section class="player-card"><header class="player-round"><p class="eyebrow" style="color:#ffc82e">Round ${state.question.round || 1} of 5</p><h1>${state.question.roundTitle}</h1></header><section class="player-question"><p class="eyebrow">${state.phase === "lobby" ? "Get ready" : state.phase === "open" ? "Question" : state.phase === "reveal" ? "Answer reveal" : "Locked"}</p><h2>${state.question.prompt}</h2>${answerControl({player:true})}<div class="submit-bar"><span class="${isSubmitted ? "submitted" : state.phase === "locked" ? "submitted locked" : ""}">${phaseMessage}</span>${state.phase === "open" ? '<button class="btn btn-primary" data-submit ' + (!answerReady() ? 'disabled' : '') + '>Submit</button>' : ''}</div></section></section></main>`, true);
}

function render() {
  if (view === "host") renderHost();
  else if (view === "player") renderPlayer();
  else renderLanding();
  attachEvents();
}

function attachEvents() {
  document.querySelector("[data-create-room]")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    button.textContent = "Creating room…";
    try {
      const hostSecret = randomRoomSecret();
      const created = await roomApi.createRoom({ hostSecret, initialState: publicRoomState() });
      sessionStorage.setItem(`quiz-host-secret:${created.roomCode}`, hostSecret);
      location.href = `?view=host&room=${encodeURIComponent(created.roomCode)}`;
    } catch (error) {
      button.disabled = false;
      button.textContent = "Create hosted room";
      alert(`Could not create the room: ${error.message}`);
    }
  });
  document.querySelector("[data-copy-link]")?.addEventListener("click", async () => {
    const input = document.querySelector('input[aria-label="Player join link"]');
    try { await navigator.clipboard.writeText(input.value); } catch { input.select(); document.execCommand("copy"); }
  });
  document.querySelector("[data-join-room]")?.addEventListener("click", async () => {
    const input = document.querySelector("[data-player-name]");
    const name = input.value.trim();
    if (!name) { input.focus(); return; }
    try {
      const joined = await roomApi.joinRoom({ roomCode, displayName: name, playerToken: playerId });
      playerName = name;
      sessionStorage.setItem("musicTriviaPlayerName", name);
      state = { ...state, ...joined.state, revision: joined.revision };
      render();
    } catch (error) { alert(`Could not join this room: ${error.message}`); }
  });
  document.querySelectorAll("[data-answer]").forEach((button) => button.addEventListener("click", () => {
    const optionId = button.dataset.answer;
    if (state.question.type === "multiple_choice") {
      const selectedSet = new Set(Array.isArray(selected) ? selected : []);
      selectedSet.has(optionId) ? selectedSet.delete(optionId) : selectedSet.add(optionId);
      selected = [...selectedSet];
    } else selected = optionId;
    if (view === "player") render();
  }));
  document.querySelector("[data-text-answer]")?.addEventListener("input", (event) => { selected = event.target.value; const submit = document.querySelector("[data-submit]"); if (submit) submit.disabled = !answerReady(); });
  document.querySelectorAll("[data-order-answer]").forEach((select) => select.addEventListener("change", () => { selected = typeof selected === "object" && !Array.isArray(selected) ? selected : {}; selected[select.dataset.orderAnswer] = select.value; render(); }));
  document.querySelectorAll("[data-match-answer]").forEach((select) => select.addEventListener("change", () => { selected = typeof selected === "object" && !Array.isArray(selected) ? selected : {}; selected[select.dataset.matchAnswer] = select.value; render(); }));
  document.querySelectorAll("[data-phase]").forEach((button) => button.addEventListener("click", () => button.dataset.phase === "locked" ? lockQuestion() : setPhase(button.dataset.phase)));
  document.querySelector("[data-next]")?.addEventListener("click", advanceQuestion);
  document.querySelector("[data-reset]")?.addEventListener("click", reset);
  document.querySelector("[data-submit]")?.addEventListener("click", () => {
    if (selected === null) return;
    state.submitted[playerId] = selected;
    sendSubmission(selected);
    if (params.has("room")) roomApi.submitAnswer({ roomCode, playerToken: playerId, questionId: state.questionId || state.question.id || "sample-question", answer: selected, serverRevision: state.revision || 0 }).catch((error) => console.warn("Could not persist answer.", error));
    render();
  });
  document.querySelector("[data-player]")?.addEventListener("click", () => {
    const name = `Player ${state.players.length + 1}`;
    state.players.push({ id: crypto.randomUUID(), name, points: 0 }); emit(); render();
  });
  document.querySelector("[data-play]")?.addEventListener("click", (event) => {
    event.currentTarget.textContent = event.currentTarget.textContent === "▶" ? "Ⅱ" : "▶";
  });
}

window.addEventListener("keydown", (event) => {
  if (view !== "host") return;
  if (event.key.toLowerCase() === "n" && state.phase === "lobby") setPhase("open");
  if (event.key.toLowerCase() === "n" && state.phase === "reveal") advanceQuestion();
  if (event.key.toLowerCase() === "l" && state.phase === "open") lockQuestion();
  if (event.key.toLowerCase() === "r" && state.phase === "locked") setPhase("reveal");
});

render();
connectHostedRoom();
